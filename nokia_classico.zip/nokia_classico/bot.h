#ifndef BOT_H_
#define BOT_H_

#define BUTTON_NOT_PRESSED (-1)

void ConfigureButtons();

int GetButton();



#endif /* BOT_H_ */
